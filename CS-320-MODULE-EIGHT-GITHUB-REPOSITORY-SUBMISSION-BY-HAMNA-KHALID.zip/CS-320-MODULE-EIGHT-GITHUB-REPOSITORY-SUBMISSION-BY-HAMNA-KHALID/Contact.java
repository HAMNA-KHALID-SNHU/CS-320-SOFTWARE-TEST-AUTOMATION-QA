package PROJECTONE;

public class Contact {

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {

        if (contactId == null) {
            throw new IllegalArgumentException("Contact ID cannot be null.");
        }
        if (contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID cannot exceed 10 characters.");
        }

        if (firstName == null) {
            throw new IllegalArgumentException("First name cannot be null.");
        }
        if (firstName.length() > 10) {
            throw new IllegalArgumentException("First name cannot exceed 10 characters.");
        }

        if (lastName == null) {
            throw new IllegalArgumentException("Last name cannot be null.");
        }
        if (lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot exceed 10 characters.");
        }

        if (phone == null) {
            throw new IllegalArgumentException("Phone number cannot be null.");
        }
        if (!phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }

        if (address == null) {
            throw new IllegalArgumentException("Address cannot be null.");
        }
        if (address.length() > 30) {
            throw new IllegalArgumentException("Address cannot exceed 30 characters.");
        }

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if (firstName == null) {
            throw new IllegalArgumentException("First name cannot be null.");
        }
        if (firstName.length() > 10) {
            throw new IllegalArgumentException("First name cannot exceed 10 characters.");
        }
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if (lastName == null) {
            throw new IllegalArgumentException("Last name cannot be null.");
        }
        if (lastName.length() > 10) {
            throw new IllegalArgumentException("Last name cannot exceed 10 characters.");
        }
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone == null) {
            throw new IllegalArgumentException("Phone number cannot be null.");
        }
        if (!phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly 10 digits.");
        }
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        if (address == null) {
            throw new IllegalArgumentException("Address cannot be null.");
        }
        if (address.length() > 30) {
            throw new IllegalArgumentException("Address cannot exceed 30 characters.");
        }
        this.address = address;
    }
}