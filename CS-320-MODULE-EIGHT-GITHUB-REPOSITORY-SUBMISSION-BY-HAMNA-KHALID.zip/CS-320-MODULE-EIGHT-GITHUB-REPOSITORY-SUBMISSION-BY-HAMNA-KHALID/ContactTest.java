package PROJECTONE;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    // ---------- VALID CREATION ----------

    @Test
    void validContactCreation() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        assertEquals("1", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // ---------- ID VALIDATION ----------

    @Test
    void contactIdNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
    }

    @Test
    void contactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    // ---------- FIRST NAME ----------

    @Test
    void firstNameNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", null, "Doe", "1234567890", "123 Main St"));
    }

    @Test
    void firstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "VeryLongNameHere", "Doe", "1234567890", "123 Main St"));
    }

    // ---------- LAST NAME ----------

    @Test
    void lastNameNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", null, "1234567890", "123 Main St"));
    }

    @Test
    void lastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "VeryLongNameHere", "1234567890", "123 Main St"));
    }

    // ---------- PHONE ----------

    @Test
    void phoneNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Doe", null, "123 Main St"));
    }

    @Test
    void phoneNotTenDigits() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Doe", "12345", "123 Main St"));
    }

    // ---------- ADDRESS ----------

    @Test
    void addressNull() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Doe", "1234567890", null));
    }

    @Test
    void addressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Doe", "1234567890",
                        "This address is definitely more than thirty characters long"));
    }

    // ---------- SETTER TESTS ----------

    @Test
    void updateFirstName() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    void updateLastName() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    void updatePhone() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    void updateAddress() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        contact.setAddress("456 Oak Ave");
        assertEquals("456 Oak Ave", contact.getAddress());
    }

    // ---------- SETTER FAILURE CASES ----------

    @Test
    void updateFirstNameInvalid() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () ->
                contact.setFirstName("VeryLongNameHere"));
    }

    @Test
    void updatePhoneInvalid() {
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () ->
                contact.setPhone("123"));
    }

}