package PROJECTONE;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    // ---------- ADD CONTACT ----------

    @Test
    void addContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        assertEquals("John", service.getContact("1").getFirstName());
    }

    @Test
    void addNullContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(null));
    }

    @Test
    void duplicateContactIdThrowsException() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () ->
                service.addContact(contact));
    }

    // ---------- DELETE CONTACT ----------

    @Test
    void deleteContactSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);
        service.deleteContact("1");

        assertThrows(IllegalArgumentException.class, () ->
                service.getContact("1"));
    }

    @Test
    void deleteNullContactIdThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteContact(null));
    }

    @Test
    void deleteNonExistingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteContact("999"));
    }

    // ---------- UPDATE CONTACT ----------

    @Test
    void updateContactFieldsSuccessfully() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        service.updateFirstName("1", "Jane");
        service.updateLastName("1", "Smith");
        service.updatePhone("1", "0987654321");
        service.updateAddress("1", "456 Oak Ave");

        Contact updated = service.getContact("1");

        assertEquals("Jane", updated.getFirstName());
        assertEquals("Smith", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Oak Ave", updated.getAddress());
    }

    @Test
    void updateNonExistingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.updateFirstName("999", "Jane"));
    }

    @Test
    void updateInvalidPhoneThrowsException() {
        ContactService service = new ContactService();
        Contact contact = new Contact("1", "John", "Doe", "1234567890", "123 Main St");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () ->
                service.updatePhone("1", "123"));
    }

    // ---------- GET CONTACT ----------

    @Test
    void getNullContactIdThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.getContact(null));
    }

    @Test
    void getNonExistingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () ->
                service.getContact("999"));
    }
}